import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import {AddcourseComponent} from '../addcourse/addcourse.component';
import {CoursesJsonComponent} from '../courses-json/courses-json.component'

const appRoutes:Routes=[
  {path:'addC', component:AddcourseComponent},
  {path:'searchC', component:CoursesJsonComponent},
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(
      appRoutes,
      {enableTracing:true}
    )
  ],
  exports:[
    RouterModule
  ],
  declarations: []
})
export class RoutingModule { }