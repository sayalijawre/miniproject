export interface CourseJson
{
    courseId:number;
    courseName:string;
    coursePrice:number
}