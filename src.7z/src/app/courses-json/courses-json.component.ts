import { Component, OnInit } from '@angular/core';
import {CourseserviceService} from './courseservice.service';
import {CourseJson} from './courseJson';


@Component({
  selector: 'app-courses-json',
  templateUrl: './courses-json.component.html',
  styleUrls: ['./courses-json.component.css']
})
export class CoursesJsonComponent implements OnInit {

  coursejson:CourseJson[];
  constructor(private courseService:CourseserviceService) { }

  ngOnInit() {
    this.getJsonUrl();
  }
  getJsonUrl():void{
    this.courseService.getjsonUrl().subscribe(coursejson=>this.coursejson=coursejson)
  }

}
