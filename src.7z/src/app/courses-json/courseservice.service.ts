import { Injectable,OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {CourseJson} from './courseJson';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseserviceService implements OnInit{

  constructor(private http: HttpClient) { }
  jsonUrl='assets/courses.json';

  ngOnInit(){
    this.getjsonUrl();
  }

  getjsonUrl():Observable<CourseJson[]>{
    return this.http.get<CourseJson[]>(this.jsonUrl)
  }
}
