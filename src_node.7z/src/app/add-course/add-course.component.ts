import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

import {
  ReactiveFormsModule,
  FormsModule,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'


@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {


  c = [];
  public dur:string;
  public name: string;
  public time: number;
  public courseN: string;
  public courseObj: string;
  constructor(private myService: CourseService) { }
  ngOnInit() {
    this.myService.getjsonUrl().subscribe(data => (this.c = data));
  }
  onSubmit() {
    this.courseObj =
      '{"courseName":"' +
      this.name +
      '","courseDuration":' +
      this.time +
      "}";

    this.myService.postjsonUrl(JSON.parse(this.courseObj)).subscribe(data => (this.c = data));
  }
  getDuration(val:string){
     console.log(this.courseN);
    var search:boolean=false;
    if(this.courseN != null){    
      for (var i = 0; i < this.c.length; i++) {        
        if (this.courseN == this.c[i].courseName) {         
          this.dur = this.c[i].courseName+" is of " + this.c[i].courseDuration + " hrs";
          search=true; 
        }
        
    }
     if(search==false){
      this.dur="Course not found!!"
    }    
    this.courseN=null;
   
  }
  else{
   this.dur="Provide Course Name to get its duration!!"
    
  }
  }

}
