export interface Course{
    courseName:string,
    courseDuration:number
}