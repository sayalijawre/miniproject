import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AddCourseComponent} from './add-course/add-course.component';
import {RouterModule,Routes} from '@angular/router';
import {JsonCourseComponent} from './json-course/json-course.component'


const appRoutes:Routes=[
  {path:'addC', component:AddCourseComponent},
  {path:'courseJson', component:JsonCourseComponent}
  
]


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(
      appRoutes,
      {enableTracing:true}
    )
  ],
  exports:[
    RouterModule
  ],
  declarations: []
})




export class AppRoutingModule { }
