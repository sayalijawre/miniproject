import { Injectable,OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Course} from './course';

@Injectable({
  providedIn: 'root'
})
export class CourseService  {

  constructor(private http: HttpClient) { }
  getUrl='http://localhost:3000/mini/get';
  postUrl='http://localhost:3000/mini/post';
  jsonUrl='http://localhost:3000/mini/getjson';
 
 

  getjsonUrl():Observable<Course[]>{
    return this.http.get<Course[]>(this.getUrl)
  }
  postjsonUrl(data):Observable<Course[]>{
    return this.http.post<Course[]>(this.postUrl,data)
  }
   jsongetUrl():Observable<Course[]>{
    return this.http.get<Course[]>(this.jsonUrl)
  }
}
