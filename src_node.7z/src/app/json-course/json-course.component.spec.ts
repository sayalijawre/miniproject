import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JsonCourseComponent } from './json-course.component';

describe('JsonCourseComponent', () => {
  let component: JsonCourseComponent;
  let fixture: ComponentFixture<JsonCourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JsonCourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JsonCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
