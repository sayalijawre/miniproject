import { Component, OnInit } from '@angular/core';
import {CourseService} from '../course.service';

@Component({
  selector: 'app-json-course',
  templateUrl: './json-course.component.html',
  styleUrls: ['./json-course.component.css']
})
export class JsonCourseComponent implements OnInit {
  c=[];
  constructor(private myService:CourseService) { }

  ngOnInit() {
 this.myService.jsongetUrl().subscribe(data => (this.c = data));
  }

}
