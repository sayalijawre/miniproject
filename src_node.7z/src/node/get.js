var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');

exp.route('/mini/get', cors()).get((req, res) => {
    var myData;
    fs.readFile('data.json',function(err,data){
        myData=JSON.parse(data.toLocaleString())
        res.send(myData)
    })
})
exp.use(parser.json());
exp.route('/mini/post', cors()).post((req, res) => {
 fs.readFile('data.json', function (err, data) {
        fileData = JSON.parse(data.toLocaleString());
        fileData.push(req.body);
        console.log(fileData)
        fs.writeFileSync('data.json', JSON.stringify(fileData))
        res.send(fileData)
        res.end()
    });
})
/*
exp.get('/mini/getDuration', cors(), (req, res) => {
    var fileData;
    var uname=req.body;
    var block;
    console.log(uname)
   fs.readFile('data.json', function (err, data) {
        fileData = JSON.parse(data.toLocaleString());
        for (i = 0; i < fileData.length; i++) {
            if (uname.match(fileData[i].courseName)) {
                block= fileData[i].courseDuration;
            }
        }
        
        res.send(block)
        res.end();
    });
})*/

exp.route('/mini/getjson', cors()).get((req, res) => {
    var myData;
    fs.readFile('courses.json',function(err,data){
        myData=JSON.parse(data.toLocaleString())
        res.send(myData)
    })
})

exp.use(cors()).listen(3000, () => console.log("RUNNING...."));